package com.example.database;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

import androidx.annotation.Nullable;

import java.util.List;

public class displayActivity extends ListActivity {
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //实例化DBhelper
        final DBHelper helper = new DBHelper(this);
        //获得查询后的结果
        Cursor c = helper.query();
        //列表项数组
        String[] from={"_id","name","hobby"};
        //列表项ID
        int[] to={R.id.id,R.id.name,R.id.like};
        //适配器
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(this,R.layout.display,c,from,to);
        //列表视图
        ListView listView =getListView();
        //为列表项添加适配器
        listView.setAdapter(adapter);

        //对话框

        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        //列表监听点击事件
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final long temp=id;
                builder.setMessage("是否删除记录？").setPositiveButton("是", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //删除数据
                        helper.del((int)temp);
                        //查询
                        Cursor c=helper.query();
                        String[] from={"_id","name","hobby"};
                        int[] to ={R.id.id,R.id.name,R.id.like};
                        SimpleCursorAdapter adapter =new SimpleCursorAdapter(getApplicationContext(),R.layout.display,c,from,to);
                        ListView listView=getListView();
                        listView.setAdapter(adapter);
                    }
                }).setNegativeButton("否", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                AlertDialog ad=builder.create();
                ad.show();
            }
        });
        helper.close();
    }
}
