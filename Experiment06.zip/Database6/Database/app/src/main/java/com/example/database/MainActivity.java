package com.example.database;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private EditText et1,et2;
    private Button b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et1=(EditText)findViewById(R.id.name);
        et2=(EditText)findViewById(R.id.like);
        b=(Button)findViewById(R.id.add);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name = et1.getText().toString();
                String like = et2.getText().toString();
                ContentValues values = new ContentValues();
                //value中导入内容
                values.put("name",name);
                values.put("hobby",like);
                //实例化数据库类
                DBHelper helper =new DBHelper(getApplicationContext());
                //插入数据
                helper.insert(values);
                //实例化意图
                Intent intent = new Intent(MainActivity.this,displayActivity.class);
                //启动意图
                startActivity(intent);
            }
        });
    }
}