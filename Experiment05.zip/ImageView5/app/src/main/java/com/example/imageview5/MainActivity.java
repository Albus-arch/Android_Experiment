package com.example.imageview5;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private ImageView miv1;
    private final int SUCCESS=200;
    private final int ERROR=404;
    private final  String PATH="ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=2333871741,2177125813&fm=26&gp=0.jpg";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        miv1=findViewById(R.id.iv_1);
    }
   //定义Handler，用于接收子线程发过来的信息
   private Handler mHandler = new Handler(){
       @Override
       public void handleMessage(Message msg) {
           super.handleMessage(msg);
           switch (msg.what) {
               case SUCCESS:
                   miv1.setImageBitmap((Bitmap) msg.obj);
                   break;
               case ERROR:
                   Toast.makeText(MainActivity.this, "下载失败,请检查原因", Toast.LENGTH_LONG).show();
                   break;
           }

           if (null != progressDialog)
               progressDialog.dismiss();
       }
   };

    private ProgressDialog progressDialog = null;

    public void getImage(View view) {
        progressDialog = new ProgressDialog(MainActivity.this);
        progressDialog.setMessage("正在下载...");
        progressDialog.show();
        // 开启子线程 下载图片,执行此方法才去启动线程下载
        new Thread(new DownloadImage()).start();
    }

    class DownloadImage implements Runnable {
        //发送Handler
        public void showUiImage(int responseCode, Bitmap bitmap) {
            Message message = mHandler.obtainMessage(responseCode); // 拿系统消息池的消息
            message.obj = bitmap;
            mHandler.sendMessageDelayed(message, 2000);
        }

        @Override
        public void run() {
            try {
                // 封装成网络地址
                URL url = new URL(PATH);

                // 打开一个连接
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();

                // 设置连接时长
                httpURLConnection.setConnectTimeout(5000);

                // 设置请求方式
                httpURLConnection.setRequestMethod("GET");

                /**
                 * 注意：⚠️ 不要肤浅的任务 打开连接对象 设置连接时长 设置请求方式 就向服务器发送Http请求了
                 *          是要执行httpURLConnection.getResponseCode()才会向服务器发送Http请求
                 */
                if (httpURLConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    // 得到服务器返回过来的流对象
                    InputStream inputStream = httpURLConnection.getInputStream();
                    Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                    showUiImage(SUCCESS, bitmap);
                } else {
                    showUiImage(ERROR, null);
                }

            } catch (Exception e) {
                e.printStackTrace();
                showUiImage(ERROR, null);
            }
        }
    }
}