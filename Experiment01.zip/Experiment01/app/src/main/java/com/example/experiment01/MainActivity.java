package com.example.experiment01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "ActivityLifeCycle" ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.v(TAG,"onCreate");
    }

    @Override
    protected void onDestroy() {
        Log.v(TAG,"onDestroy");
        super.onDestroy();
    }

    @Override
    protected void onPause() {
        Log.v(TAG,"onPause");
        super.onPause();
    }

    @Override
    protected void onRestart() {
        Log.v(TAG,"onRestart");
        super.onRestart();
    }

    @Override
    protected void onResume() {
        Log.v(TAG,"onResume");
        super.onResume();
    }

    @Override
    protected void onStart() {
        Log.v(TAG,"onStart");
        super.onStart();
    }

    @Override
    protected void onStop() {
        Log.v(TAG,"onStop");
        super.onStop();
    }
}

