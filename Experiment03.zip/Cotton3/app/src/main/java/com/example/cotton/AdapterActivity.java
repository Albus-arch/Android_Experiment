package com.example.cotton;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class AdapterActivity extends BaseAdapter {

    private Context mContext;
    private LayoutInflater mLayoutInflater;

    AdapterActivity(Context context){
        this.mContext=context;
        mLayoutInflater=LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return 3;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    static class ViewHolder{
        public ImageView imageView;
        public TextView tvname,tvmassage;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder=null;
        if(convertView==null){
            convertView=mLayoutInflater.inflate(R.layout.activity_adapter,null);
            holder=new ViewHolder();
            holder.imageView=convertView.findViewById(R.id.iv_1);
            holder.tvname=convertView.findViewById(R.id.tv_name);
            holder.tvmassage=convertView.findViewById(R.id.tv_massage);

            convertView.setTag(holder);
        }
        else{
            holder= (ViewHolder) convertView.getTag();
        }
        //给控件赋值
        holder.tvname.setText("Albus");
        holder.tvmassage.setText("滑稽");
        holder.imageView.setImageResource(R.drawable.icon_1);
        return convertView;
    }
}