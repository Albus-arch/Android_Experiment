package com.example.experiment02;


import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.Toast;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    private Button button1;
    private TextView tv1;
    private TextView tv2;
    private TextView jg1;
    private RadioGroup radioGroup1;
    private RadioGroup radioGroup2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv1 = (TextView)findViewById(R.id.tv1);
        tv2 = (TextView)findViewById(R.id.tv2);
        jg1 = (TextView)findViewById(R.id.jg1);
        button1 = (Button)findViewById(R.id.sure1);
        radioGroup1 = (RadioGroup)findViewById(R.id.radiogroup1);
        radioGroup2 = (RadioGroup)findViewById(R.id.radiogroup2);
        radioGroup1.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup arg0, int arg1) {
                //获取变更后的选中项的ID
                int radioButtonId = arg0.getCheckedRadioButtonId();
                //根据ID获取RadioButton的实例
                RadioButton rb = (RadioButton)MainActivity.this.findViewById(radioButtonId);
                //更新文本内容，以符合选中项
                tv1.setText("甲出的是：" + rb.getText());
            }
        });
        radioGroup2.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup arg0, int arg1) {
                //获取变更后的选中项的ID
                int radioButtonId = arg0.getCheckedRadioButtonId();
                //根据ID获取RadioButton的实例
                RadioButton rb = (RadioButton)MainActivity.this.findViewById(radioButtonId);
                //更新文本内容，以符合选中项
                tv2.setText("乙出的是：" + rb.getText());
            }
        });
        button1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if(tv1.getText().equals("甲出的是：剪刀") && tv2.getText().equals("乙出的是：布")){
                    jg1.setText("结果：甲赢");
                }
                else if(tv1.getText().equals("甲出的是：剪刀") && tv2.getText().equals("乙出的是：石头")){
                    jg1.setText("结果：乙赢");
                }
                else if(tv1.getText().equals("甲出的是：剪刀") && tv2.getText().equals("乙出的是：剪刀")){
                    jg1.setText("结果：平局");
                }
                else if(tv1.getText().equals("甲出的是：石头") && tv2.getText().equals("乙出的是：石头")){
                    jg1.setText("结果：平局");
                }
                else if(tv1.getText().equals("甲出的是：石头") && tv2.getText().equals("乙出的是：布")){
                    jg1.setText("结果：乙赢");
                }
                else if(tv1.getText().equals("甲出的是：石头") && tv2.getText().equals("乙出的是：剪刀")){
                    jg1.setText("结果：甲赢");
                }
                else if(tv1.getText().equals("甲出的是：布") && tv2.getText().equals("乙出的是：剪刀")){
                    jg1.setText("结果：乙赢");
                }
                else if(tv1.getText().equals("甲出的是：布") && tv2.getText().equals("乙出的是：石头")){
                    jg1.setText("结果：甲赢");
                }
                else if(tv1.getText().equals("甲出的是：布") && tv2.getText().equals("乙出的是：布")){
                    jg1.setText("结果：平局");
                }


            }
        });
    }
}