package com.ccf.feige.activity;

public class Constant {
	public final static String END="end";
	public final static String HOST_SPOT_SSID="FeiGe";
	public final static String HOST_SPOT_PASS_WORD="123456789";

}

