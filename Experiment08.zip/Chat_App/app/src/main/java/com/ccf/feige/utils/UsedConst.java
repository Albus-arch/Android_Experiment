package com.ccf.feige.utils;

/*
 * 一些用到的常量
 * 
 */
public class UsedConst {
	public static final int FILESENDSUCCESS  = 0xFF;	//文件发送成功
	public static final int FILERECEIVEINFO = 0xFE;		//接收文件，包含文件信息
	public static final int FILERECEIVESUCCESS = 0xFD;		//接收文件，包含文件信息
}
